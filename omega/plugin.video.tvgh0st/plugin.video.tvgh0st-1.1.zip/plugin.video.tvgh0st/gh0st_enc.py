# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import urllib.parse
from lib.helper import *
from lib import xtream, tunein, pluto, imdb, api_vod
import os
import sys

def show_welcome():
    try:
        # Caminho para o perfil no Kodi
        profile_path = os.path.join(os.getenv('HOME'), '.kodi', 'userdata')  # Para o Android
    except AttributeError:
        profile_path = os.path.join(os.getenv('HOME'), '.kodi', 'userdata')  # Alternativo para o Android

    settings_file = os.path.join(profile_path, 'welcome_shown.txt')
    current_version = "1.1"  # Atualize para a versão

    # Verifica se o arquivo existe
    if not os.path.exists(settings_file):
        # Exibe o diálogo e continua a execução
        show_dialog(current_version)
        update_version_file(current_version)
    else:
        # Lê o conteúdo do arquivo para verificar a versão armazenada
        with open(settings_file, 'r') as f:
            stored_version = f.read().strip()

        # Se a versão armazenada for diferente da atual, exibe o diálogo novamente
        if stored_version != current_version:
            show_dialog(current_version)
            update_version_file(current_version)

def show_dialog(version):
    dialog = xbmcgui.Dialog()
    message = f"[B][COLOR lime]TELEGRAM =>[/COLOR][/B] [B]@gh000000000000st[/B]\n[B][COLOR lime]VERSÃO DO PLUGIN =>[/COLOR][/B] [B]{version}[/B]\n[B][COLOR lime]ADD-ON BASE =>[/COLOR][/B][B] Zoreu\n[B][COLOR lime]PLATAFORMAS =>[/COLOR][/B] [B]ANDROID & WINDOWS ✅[/B]"
    dialog.ok("[BEM-VINDO AO TV GHOST]", message)

def update_version_file(version):
    # Define o caminho para o arquivo de configuração do perfil
    profile_path = os.path.join(os.getenv('HOME'), '.kodi', 'userdata')
    settings_file = os.path.join(profile_path, 'welcome_shown.txt')
    
    # Atualiza o arquivo com a versão atual
    with open(settings_file, 'w') as f:
        f.write(version)

if __name__ == "__main__":
    show_welcome()
    
# BASIC CONFING
TITULO1 = '[B][COLOR cyan]d_b ||[/B][/COLOR] [B][COLOR magenta]TVSTREAMPRO[B][COLOR green][++][/B][/COLOR] [B][COLOR cyan]|| d_b[/B][/COLOR]'
API_CHANNELS = 'https://raw.githubusercontent.com/BLACKSHEEPcolabdev/add-on/refs/heads/master/BLACKGHOST/gh0st.json'
TITULO2 = '[B][COLOR cyan]d_b || [B][COLOR orange]TELEGRAM:[/B][/COLOR] [B][COLOR cyan]@BLACKGHOST_B[/B][/COLOR] [B]|| d_b[/B][/COLOR]'
TITULO3 = '[B][COLOR orange]======================================[/B][/COLOR]'
TITULO4 = '[B][COLOR orange]======================================[/B][/COLOR]'
TITULO5 = '[B][COLOR orange]======================================[/B][/COLOR]'
TITULO6 = '[B][COLOR orange]======================================[/B][/COLOR]'
if not exists(profile):
    try:
        os.mkdir(profile)
    except:
        pass
IPTV_PROBLEM_LOG = translate(os.path.join(profile, 'iptv_problems_log.txt'))


@route('/')
def index():
    addMenuItem({'name': TITULO1, 'description': '[B][COLOR green]BEM-VINDO AO [B][COLOR magenta]TVSTREAMPRO[/B][/COLOR][++]! APROVEITE FILMES E CANAIS AO VIVO EM UM SÓ LUGAR.[/COLOR]'}, destiny='')
    addMenuItem({'name': TITULO3, 'description': '[B][COLOR red]AVISO PRA QUEM ESTA ENFRENTANDO ERRO AO ASSISTIR OS CANAIS DE TV AO VIVO, ACONSELHAMOS O USO DE UMA [B][COLOR cyan]VPN[/B][/COLOR] [B]OU DE UM[/B] [B][COLOR cyan]DNS[/B][/COLOR] [B]PARA FUNCIONAR CORRETAMENTE OS CANAIS DE TV![/B][B][COLOR magenta] TVSTREAMPRO[/B][/COLOR][B][COLOR green][++][/B][/COLOR].[/COLOR] [B][COLOR gold] OBRIGADO POR USAR NOSSO ADD-ONS[/B][/COLOR] [B][COLOR red]sz[/B][/COLOR]'}, destiny='')
    addMenuItem({'name': '[B][COLOR magenta]TVSTREAMPRO[++][/B][/COLOR] - [B]TV AO VIVO[/B]', 'description': '[B][COLOR green]ACESSE LISTA DE CANAIS IPTV PERSONALIZADA NO[/B][/COLOR] [B][COLOR magenta]TVSTREAMPRO[/B][/COLOR][B][COLOR green][++][/B][/COLOR]'}, destiny='/playlistiptv')
    
    if six.PY3:
        addMenuItem({'name': '[B][COLOR magenta]TVSTREAMPRO[++][/B][/COLOR] - [B]PLUTO TV[/B]', 'description': '[B][COLOR green]EXPLORE OS CANAIS DISPONÍVEIS NA PLUTO TV DIRETAMENTE PELO[/B][/COLOR] [B][COLOR magenta]TVSTREAMPRO[/B][/COLOR][B][COLOR green][++][/B][/COLOR]'}, destiny='/channels_pluto')
    
    addMenuItem({'name': '[B][COLOR magenta]TVSTREAMPRO[++][/B][/COLOR] - [B]IMDB FILMES[/B]', 'description': '[B][COLOR green]CONFIRA OS FILMES POPULARES IMDB ATRAVÉS DO[/B][/COLOR] [B][COLOR magenta]TVSTREAMPRO[/B][/COLOR][B][COLOR green][++][/B][/COLOR]'}, destiny='/imdb_movies')
    addMenuItem({'name': '[B][COLOR magenta]TVSTREAMPRO[++][/B][/COLOR] - [B]IMDB SÉRIES[/B]', 'description': '[B][COLOR green]CONFIRA AS SERIES POPULARES IMDB ATRAVÉS DO[/B][/COLOR] [B][COLOR magenta]TVSTREAMPRO[/B][/COLOR][B][COLOR green][++][/B][/COLOR]'}, destiny='/imdb_series')
    
    addMenuItem({'name': TITULO4, 'description': '[B][COLOR red]AVISO PRA QUEM ESTA ENFRENTANDO ERRO AO ASSISTIR OS CANAIS DE TV AO VIVO, ACONSELHAMOS O USO DE UMA [B][COLOR cyan]VPN[/B][/COLOR] [B]OU DE UM[/B] [B][COLOR cyan]DNS[/B][/COLOR] [B]PARA FUNCIONAR CORRETAMENTE OS CANAIS DE TV![/B][B][COLOR magenta] TVSTREAMPRO[/B][/COLOR][B][COLOR green][++][/B][/COLOR].[/COLOR] [B][COLOR gold] OBRIGADO POR USAR NOSSO ADD-ONS[/B][/COLOR] [B][COLOR red]sz[/B][/COLOR]'}, destiny='')
    addMenuItem({'name': TITULO2, 'description': '[B][COLOR red]PRECISA DE AJUDA?[/B][/COLOR] [B][COLOR green]ENTRE EM CONTATO PARA SUPORTE AO[/B][/COLOR] [B][COLOR magenta]TVSTREAMPRO[++][/B][/COLOR]'}, destiny='')
    
    end()
    setview('WideList')

@route('/playlistiptv')
def playlistiptv(): 
    iptv = xtream.parselist(API_CHANNELS)
    if iptv:
        for n, (dns, username, password) in enumerate(iptv):
            n = n + 1
            addMenuItem({'name': '[B][COLOR magenta]TVSTREAMPRO[++][/B][/COLOR] - [B][COLOR gold]LISTA d[ [B][COLOR pink]{0}[/B][/COLOR] [B]]b[/B][/COLOR]'.format(str(n)), 'description': '[B][COLOR red]AVISO PRA QUEM ESTA ENFRENTANDO ERRO AO ASSISTIR OS CANAIS DE TV AO VIVO, ACONSELHAMOS O USO DE UMA [B][COLOR cyan]VPN[/B][/COLOR] [B]OU DE UM[/B] [B][COLOR cyan]DNS[/B][/COLOR] [B]PARA FUNCIONAR CORRETAMENTE OS CANAIS DE TV![/B][B][COLOR magenta] TVSTREAMPRO[/B][/COLOR][B][COLOR green][++][/B][/COLOR].[/COLOR] [B][COLOR gold] OBRIGADO POR USAR NOSSO ADD-ONS[/B][/COLOR] [B][COLOR red]sz[/B][/COLOR].', 'dns': dns, 'username': str(username), 'password': str(password)}, destiny='/cat_channels')
        end()
        setview('WideList') 
    else:
        notify('SEM LISTA M3U') 


@route('/cat_channels')
def cat_channels(param):
    dns = param['dns']
    username = param['username']
    password = param['password']
    cat = xtream.API(dns,username,password).channels_category()
    if cat:
        for i in cat:
            name, url = i
            addMenuItem({'name': name, 'description': '', 'dns': dns, 'username': str(username), 'password': str(password), 'url': url}, destiny='/open_channels')
        end()
        setview('WideList')
    else:
        url_problem = '{0}/get.php?username={1}&password={2}\n'.format(dns,username,password)
        if six.PY2:
            import io
            open_file = lambda filename, mode: io.open(filename, mode, encoding='utf-8')
        else:
            open_file = lambda filename, mode: open(filename, mode, encoding='utf-8')
        if exists(IPTV_PROBLEM_LOG):
            check = False
            with open(IPTV_PROBLEM_LOG, "r") as arquivo:
                if url_problem in arquivo.read():
                    check = True
        else:
            check = False
        with open_file(IPTV_PROBLEM_LOG, "a") as arquivo:
            if not check:
                arquivo.write(url_problem)
        notify('LISTA OFFLINE :(')

@route('/open_channels')
def open_channels(param):
    dns = param['dns']
    username = param['username']
    password = param['password']
    url = param['url'] 
    open_ = xtream.API(dns,username,password).channels_open(url)
    if open_:
        setcontent('movies')
        for i in open_:
            name,link,thumb,desc = i
            addMenuItem({'name': name, 'description': desc, 'iconimage': thumb, 'url': link}, destiny='/play_iptv', folder=False)
        end()
        setview('List')
    else:
        notify('OPÇÃO INDISPONIVEL')


# Função play_with_inputstream deve ser definida antes de ser chamada
def play_with_inputstream(name, url, iconimage, description=None, header=None):
    """Configura e reproduz o fluxo usando inputstream.ffmpegdirect"""
    list_item = xbmcgui.ListItem(label=name)
    list_item.setPath(url)
    list_item.setContentLookup(False)
    list_item.setArt({"icon": iconimage, "thumb": iconimage})
    list_item.setMimeType("application/vnd.apple.mpegurl")

    # Configuração do inputstream.ffmpegdirect
    list_item.setProperty('inputstreamaddon', 'inputstream.ffmpegdirect')
    list_item.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
    list_item.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')

    # Adiciona cabeçalhos, se fornecidos
    if header:
        list_item.setProperty("inputstream.ffmpegdirect.manifest_headers", header)

    # Adiciona informações extras, se disponíveis
    if description:
        list_item.setInfo('video', {"Title": name, "Plot": description})

    try:
        xbmc.Player().play(item=url, listitem=list_item)
    except Exception as e:
        xbmc.log(f"Erro ao reproduzir com ffmpegdirect: {e}", xbmc.LOGERROR)

# Função para reproduzir IPTV
@route('/play_iptv')
def play_iptv(params):
    name = params.get('name', '')
    description = params.get('description', '')
    iconimage = params.get('iconimage', '')
    url = params.get('url', '')
    
    # Menu de escolha
    dialog = xbmcgui.Dialog()
    choice = dialog.select("Escolha o reprodutor", ["f4mTester", "inputstream.ffmpegdirect"])
    
    if choice == 0:  # Escolheu f4mTester
        plugin = (
            'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&name=' +
            urllib.parse.quote_plus(name) +
            '&iconImage=' + urllib.parse.quote_plus(iconimage) +
            '&url=' + urllib.parse.quote_plus(url)
        )
        xbmc.executebuiltin('RunPlugin(%s)' % plugin)
    elif choice == 1:  # Escolheu inputstream.ffmpegdirect
        play_with_inputstream(name, url, iconimage, description)
    else:  # Cancelou
        xbmc.executebuiltin('Notification(Aviso, Nenhum reprodutor selecionado, 3000)')


# Função play_iptv2 semelhante à play_iptv
@route('/play_iptv2')
def play_iptv2(params):
    url = params.get('url', '')
    name = params.get('name', 'IPTV Stream')
    description = params.get('description', '')
    iconimage = params.get('iconimage', '')
    header = urllib.parse.unquote_plus(url.split('|')[1]) if '|' in url else ''
    
    # Exibe opções para o usuário
    dialog = xbmcgui.Dialog()
    choice = dialog.select("Escolha o reprodutor", ["f4mTester", "inputstream.ffmpegdirect"])
    
    if choice == 0:  # Escolheu f4mTester
        plugin = (
            'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&name=' +
            urllib.parse.quote_plus(name) +
            '&iconImage=' + urllib.parse.quote_plus(iconimage) +
            '&url=' + urllib.parse.quote_plus(url)
        )
        xbmc.executebuiltin('RunPlugin(%s)' % plugin)
    elif choice == 1:  # Escolheu inputstream.ffmpegdirect
        play_with_inputstream(name, url, iconimage, description, header)
    else:  # Cancelou
        xbmc.executebuiltin('Notification(Aviso, Nenhum reprodutor selecionado, 3000)')


def play_with_inputstream(name, url, iconimage, description=None, header=None):
    """Configura e reproduz o fluxo usando inputstream.ffmpegdirect"""
    list_item = xbmcgui.ListItem(label=name)
    list_item.setPath(url)
    list_item.setContentLookup(False)
    list_item.setArt({"icon": iconimage, "thumb": iconimage})
    list_item.setMimeType("application/vnd.apple.mpegurl")

    # Configuração do inputstream.ffmpegdirect
    list_item.setProperty('inputstreamaddon', 'inputstream.ffmpegdirect')
    list_item.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
    list_item.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')

    # Adiciona cabeçalhos, se fornecidos
    if header:
        list_item.setProperty("inputstream.ffmpegdirect.manifest_headers", header)

    # Adiciona informações extras, se disponíveis
    if description:
        list_item.setInfo('video', {"Title": name, "Plot": description})

    try:
        xbmc.Player().play(item=url, listitem=list_item)
    except Exception as e:
        xbmc.log(f"Erro ao reproduzir com ffmpegdirect: {e}", xbmc.LOGERROR)


@route('/channels_pluto')
def channels_pluto():
    channels = pluto.playlist_pluto()
    if channels:
        setcontent('movies')
        for channel in channels:
            channel_name,desc,thumbnail,stream = channel
            addMenuItem({'name': channel_name, 'description': desc, 'iconimage': thumbnail, 'url': stream}, destiny='/play_iptv2', folder=False)
        end()
        setview('List') 


@route('/radios')
def radios():
    tunein.radios_list(API_RADIOS)

@route('/imdb_movies')
def imdb_series():
    addMenuItem({'name': '[B][COLOR magenta]TVSTREAMPRO[++][/B][/COLOR] - [B][COLOR gold]PESQUISAR FILMES[/B][/COLOR]', 'description': 'FILMES POPULARES COM BASE EM API'}, destiny='/find_movies')
    addMenuItem({'name': '[B][COLOR magenta]TVSTREAMPRO[++][/B][/COLOR] - [B][COLOR gold]FILMES TOP 250[/B][/COLOR]', 'description': 'FILMES POPULARES COM BASE EM API'}, destiny='/imdb_movies_250')
    addMenuItem({'name': '[B][COLOR magenta]TVSTREAMPRO[++][/B][/COLOR] - [B][COLOR gold]FILMES POPULARES[/B][/COLOR]', 'description': 'FILMES POPULARES COM BASE EM API'}, destiny='/imdb_movies_popular')
    end()
    setview('WideList')


@route('/imdb_series')
def imdb_series():
    addMenuItem({'name': '[B][COLOR magenta]TVSTREAMPRO[++][/B][/COLOR] - [B][COLOR gold]PESQUISAR SÉRIES[/B][/COLOR]', 'description': 'SÉRIES POPULARES COM BASE EM API'}, destiny='/find_series')
    addMenuItem({'name': '[B][COLOR magenta]TVSTREAMPRO[++][/B][/COLOR] - [B][COLOR gold]SÉRIES TOP 250[/B][/COLOR]', 'description': 'SÉRIES POPULARES COM BASE EM API'}, destiny='/imdb_series_250')
    addMenuItem({'name': '[B][COLOR magenta]TVSTREAMPRO[++][/B][/COLOR] - [B][COLOR gold]SÉRIES POPULARES[/B][/COLOR]', 'description': 'SÉRIES POPULARES COM BASE EM API'}, destiny='/imdb_series_popular')
    end()
    setview('WideList')


@route('/find_movies')
def find_movies():
    search = input_text(heading='Pesquisar')
    if search:
        itens = imdb.IMDBScraper().search_movies(search)
        if itens:
            setcontent('movies')
            for i in itens:
                name,img,page,year,imdb_id = i
                addMenuItem({'name': name, 'description': '', 'iconimage': img, 'url': '', 'imdbnumber': imdb_id}, destiny='/play_resolve_movies', folder=False)
            end()
            setview('Wall') 

@route('/find_series')
def find_series():
    search = input_text(heading='Pesquisar')
    if search:
        itens = imdb.IMDBScraper().search_series(search)
        if itens:
            setcontent('tvshows')
            for i in itens:
                name,img,page,year,imdb_id = i
                addMenuItem({'name': name, 'description': '', 'iconimage': img, 'url': page, 'imdbnumber': imdb_id}, destiny='/open_imdb_seasons')
            end()
            setview('Wall')                 


@route('/imdb_movies_250')
def movies_250():
    itens = imdb.IMDBScraper().movies_250()
    if itens:
        setcontent('movies')
        for i in itens:
            name,image,url,description, imdb_id = i
            addMenuItem({'name': name, 'description': description, 'iconimage': image, 'url': '', 'imdbnumber': imdb_id}, destiny='/play_resolve_movies', folder=False)
        end()
        setview('Wall') 



@route('/imdb_series_250')
def series_250():
    itens = imdb.IMDBScraper().series_250()
    if itens:
        setcontent('tvshows')
        for i in itens:
            name,image,url,description, imdb_id = i
            addMenuItem({'name': name, 'description': description, 'iconimage': image, 'url': url, 'imdbnumber': imdb_id}, destiny='/open_imdb_seasons')
        end()
        setview('Wall')

@route('/imdb_movies_popular')
def movies_popular():
    itens = imdb.IMDBScraper().movies_popular()
    if itens:
        setcontent('movies')
        for i in itens:
            name,image,url,description, imdb_id = i
            addMenuItem({'name': name, 'description': description, 'iconimage': image, 'url': '', 'imdbnumber': imdb_id}, destiny='/play_resolve_movies', folder=False)
        end()
        setview('Wall')  

@route('/imdb_series_popular')
def series_popular():
    itens = imdb.IMDBScraper().series_popular()
    if itens:
        setcontent('tvshows')
        for i in itens:
            name,image,url,description, imdb_id = i
            addMenuItem({'name': name, 'description': description, 'iconimage': image, 'url': url, 'imdbnumber': imdb_id}, destiny='/open_imdb_seasons')
        end()
        setview('Wall') 

@route('/open_imdb_seasons')
def open_imdb_seasons(param):
    serie_icon = param.get('iconimage', '')
    serie_name = param.get('name', '')
    url = param.get('url', '')
    imdb_id = param.get('imdbnumber', '')
    itens = imdb.IMDBScraper().imdb_seasons(url)
    if itens:
        setcontent('tvshows')
        try:
            addMenuItem({'name': '::: ' + serie_name + ':::', 'description': '', 'iconimage': serie_icon}, destiny='')
        except:
            pass
        for i in itens:
            season_number, name, url_season = i
            addMenuItem({'name': name, 'description': '', 'iconimage': serie_icon, 'url': url_season, 'imdbnumber': imdb_id, 'season': season_number, 'serie_name': serie_name}, destiny='/open_imdb_episodes')
        end()
        setview('List')

@route('/open_imdb_episodes')
def open_imdb_episodes(param):
    serie_icon = param.get('iconimage', '')
    serie_name = param.get('serie_name', '')
    url = param.get('url', '')
    imdb_id = param.get('imdbnumber', '')
    season = param.get('season', '')
    itens = imdb.IMDBScraper().imdb_episodes(url)
    if itens:
        setcontent('tvshows')
        try:
            addMenuItem({'name': '::: ' + serie_name + ' - S' + str(season) + ':::', 'description': '', 'iconimage': serie_icon}, destiny='')
        except:
            pass 
        for i in itens:
            episode_number,name,img,fanart,description = i
            name_full = str(episode_number) + ' - ' + name
            #if not '#' in name_full and not '.' in name_full:
            addMenuItem({'name': name_full, 'description': description, 'iconimage': img, 'fanart': fanart, 'imdbnumber': imdb_id, 'season': season, 'episode': str(episode_number), 'serie_name': serie_name, 'playable': 'true'}, destiny='/play_resolve_series', folder=False)
        end()
        setview('List')

@route('/play_resolve_movies')
def play_resolve_movies(param):
    notify('Aguarde')
    # json_rpc_command = '''
    # {
    #     "jsonrpc": "2.0",
    #     "method": "Settings.SetSetting",
    #     "params": {
    #         "setting": "locale.languageaudio",
    #         "value": "por"
    #     },
    #     "id": 1
    # }
    # '''
    # xbmc.executeJSONRPC(json_rpc_command)
    import inputstreamhelper
    #serie_name = param.get('serie_name')
    #season = param.get('season', '')
    #episode = param.get('episode', '')
    iconimage = param.get('iconimage', '')
    imdb = param.get('imdbnumber', '')
    description = param.get('description', '')
    #name = serie_name + ' S' + str(season) + 'E' + str(episode)
    name = param.get('name', '')
    url = api_vod.VOD().movie(imdb)
    if url:
        notify('Escolha o audio portugues nos ajustes')

        is_helper = inputstreamhelper.Helper("hls")
        if is_helper.check_inputstream():
            if '|' in url:
                header = unquote_plus(url.split('|')[1])
            play_item = xbmcgui.ListItem(path=url)
            play_item.setContentLookup(False)
            play_item.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
            play_item.setMimeType("application/vnd.apple.mpegurl")
            if kversion >= 19:
                play_item.setProperty('inputstream', is_helper.inputstream_addon)
            else:
                play_item.setProperty('inputstreamaddon', is_helper.inputstream_addon)
            play_item.setProperty("inputstream.adaptive.manifest_type", "hls")
            if '|' in url:
                play_item.setProperty("inputstream.adaptive.manifest_headers", header)
            play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
            play_item.setProperty('inputstream.adaptive.is_realtime_stream', 'true')
            play_item.setProperty('inputstream.adaptive.original_audio_language', 'pt') 
            if kversion > 19:
                info = play_item.getVideoInfoTag()
                info.setTitle(name)
                info.setPlot(description)
                info.setIMDBNumber(str(imdb))
                #info.setSeason(int(season))
                #info.setEpisode(int(episode))
            else:
                play_item.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
                play_item.setInfo('video', {'imdbnumber': str(imdb)})
                #play_item.setInfo('video', {'season': int(season)})
                #play_item.setInfo('video', {'episode': int(episode)})

            #xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, play_item)
            xbmc.Player().play(item=url, listitem=play_item)
    else:
        notify('Stream Indisponivel') 

@route('/play_resolve_series')
def play_resolve_series(param):
    # json_rpc_command = '''
    # {
    #     "jsonrpc": "2.0",
    #     "method": "Settings.SetSetting",
    #     "params": {
    #         "setting": "locale.languageaudio",
    #         "value": "por"
    #     },
    #     "id": 1
    # }
    # '''
    # xbmc.executeJSONRPC(json_rpc_command)
    import inputstreamhelper
    serie_name = param.get('serie_name')
    season = param.get('season', '')
    episode = param.get('episode', '')
    iconimage = param.get('iconimage', '')
    imdb = param.get('imdbnumber', '')
    description = param.get('description', '')
    name = serie_name + ' S' + str(season) + 'E' + str(episode)
    url = api_vod.VOD().tvshows(imdb,season,episode)
    if url:
        notify('Escolha o audio portugues nos ajustes')

        is_helper = inputstreamhelper.Helper("hls")
        if is_helper.check_inputstream():
            if '|' in url:
                header = unquote_plus(url.split('|')[1])
            play_item = xbmcgui.ListItem(path=url)
            play_item.setContentLookup(False)
            play_item.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
            play_item.setMimeType("application/vnd.apple.mpegurl")
            if kversion >= 19:
                play_item.setProperty('inputstream', is_helper.inputstream_addon)
            else:
                play_item.setProperty('inputstreamaddon', is_helper.inputstream_addon)
            play_item.setProperty("inputstream.adaptive.manifest_type", "hls")
            if '|' in url:
                play_item.setProperty("inputstream.adaptive.manifest_headers", header)
            play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
            play_item.setProperty('inputstream.adaptive.is_realtime_stream', 'true')
            play_item.setProperty('inputstream.adaptive.original_audio_language', 'pt') 
            if kversion > 19:
                info = play_item.getVideoInfoTag()
                info.setTitle(name)
                info.setPlot(description)
                info.setIMDBNumber(str(imdb))
                info.setSeason(int(season))
                info.setEpisode(int(episode))
            else:
                play_item.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
                play_item.setInfo('video', {'imdbnumber': str(imdb)})
                play_item.setInfo('video', {'season': int(season)})
                play_item.setInfo('video', {'episode': int(episode)})

            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, play_item)
    else:
        notify('Stream Indisponivel')  



